Animation Frames


Guns Collapse Top
0 - 15

Guns Collapse Bottom
10 - 25

Guns shooting Top
30 - 38

Guns Shooting Bottom
31 - 39